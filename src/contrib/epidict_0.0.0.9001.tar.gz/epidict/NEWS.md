# epidict 0.0.0.9000

* Fix broken URLs in README
* Add vignettes and README describing the dictionaries
* Release to CRAN
* Fix bug in generating elegible and interviewed for Mortality and Nurition surveys

# epidict 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
* Generalize `gen_data()` function to be able to take different organization
  dictionaries in the future.
* Tidy code. 
