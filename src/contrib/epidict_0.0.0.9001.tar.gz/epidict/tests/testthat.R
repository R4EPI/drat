library(testthat)
library(epidict)

test_check("epidict")
