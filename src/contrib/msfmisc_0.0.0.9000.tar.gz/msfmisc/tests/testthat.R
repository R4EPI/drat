library(testthat)
library(msfmisc)

test_check("msfmisc")
