library(testthat)
library(msfdict)

test_check("msfdict")
