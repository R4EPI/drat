# matchmaker 0.1.1

* update tests to accomodate R version 4.0.0. See issue #9 for details

# matchmaker 0.1.0

* first official version of matchmaker

# matchmaker 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
