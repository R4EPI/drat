# apyramid 0.1.2

CRAN MAINTENANCE
----------------

* This version has no user-visible changes and fixes a couple of changed 
  behaviors that arose because of dplyr version 1.0.0. (#6, #7, @zkamvar).

# apyramid 0.1.1

CRAN MAINTENANCE
----------------

* A test that was failing due to ggplot2 version 3.3.0 has been fixed. The
  underlying issue was an unexpected warning being thrown due to changing
  standards in the ggplot2 package (#4, #5; @zkamvar)


# apyramid 0.1.0

* Initial version.
