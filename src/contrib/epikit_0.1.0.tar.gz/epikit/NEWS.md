# epikit 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* Update `case_fatality_rate_df()` to ignore missing values when tabulating the
  denominator (See https://github.com/R4EPI/epikit/issues/7 for details, Thanks to @thibautjombart for pointing this out).
