library(testthat)
library(apyramid)

test_check("apyramid")
