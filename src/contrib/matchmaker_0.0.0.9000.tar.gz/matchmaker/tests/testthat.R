library(testthat)
library(matchmaker)

test_check("matchmaker")
