library(testthat)
library(sitrep)

test_check("sitrep")
