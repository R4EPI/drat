# epibuffet 0.0.0.9003

* Update to {tidyselect} 1.0.0, remove warning if unused columns (#8, @zkamvar)

# epibuffet 0.0.0.9002

* Change import {msfdict} to {epidict}

# epibuffet 0.0.0.9001

* Added a `NEWS.md` file to track changes to the package.
* Change import {msfmisc} to {epikit}
* Start using continuous integration
