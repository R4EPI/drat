# epibuffet 0.0.0.9005

* update for compatibility with dplyr 1.0.2

# epibuffet 0.0.0.9004

* update tests for compatibility with dplyr v1.0.0
* add better error reporting from `tabulate_survey()` in the case of low number
  factor levels.

# epibuffet 0.0.0.9003

* Update to {tidyselect} 1.0.0, remove warning if unused columns (#8, @zkamvar)

# epibuffet 0.0.0.9002

* Change import {msfdict} to {epidict}

# epibuffet 0.0.0.9001

* Added a `NEWS.md` file to track changes to the package.
* Change import {msfmisc} to {epikit}
* Start using continuous integration
