library(testthat)
library(epikit)

test_check("epikit")
