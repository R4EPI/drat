## ----install, eval=FALSE------------------------------------------------------
#  install.packages("linelist")

## ----install2, eval=FALSE-----------------------------------------------------
#  devtools::install_github("reconhub/linelist")

