library(testthat)
library(epibuffet)

test_check("epibuffet")
